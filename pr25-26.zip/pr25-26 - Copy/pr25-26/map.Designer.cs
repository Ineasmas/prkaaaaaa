﻿namespace pr25_26
{
    partial class map
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnchek = new System.Windows.Forms.Panel();
            this.btclose = new System.Windows.Forms.Button();
            this.lb5 = new System.Windows.Forms.Label();
            this.lb4 = new System.Windows.Forms.Label();
            this.lb3 = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.lb1 = new System.Windows.Forms.Label();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lborientir = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.lbcheck = new System.Windows.Forms.Label();
            this.bt1 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt6 = new System.Windows.Forms.Button();
            this.bt7 = new System.Windows.Forms.Button();
            this.bt8 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnchek.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::pr25_26.Properties.Resources.marathon_skills_2016_marathon_map;
            this.pictureBox1.Location = new System.Drawing.Point(12, 127);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(485, 407);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(227, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "MARATHON SKILLS 2016";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1012, 54);
            this.panel1.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 48);
            this.button2.TabIndex = 15;
            this.button2.Text = "Назад";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(298, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(408, 26);
            this.label3.TabIndex = 1;
            this.label3.Text = "18 дней 8 часов и 17 минут до старта марафона!";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(-2, 622);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1012, 59);
            this.panel2.TabIndex = 11;
            // 
            // pnchek
            // 
            this.pnchek.Controls.Add(this.btclose);
            this.pnchek.Controls.Add(this.lb5);
            this.pnchek.Controls.Add(this.lb4);
            this.pnchek.Controls.Add(this.lb3);
            this.pnchek.Controls.Add(this.lb2);
            this.pnchek.Controls.Add(this.lb1);
            this.pnchek.Controls.Add(this.pb5);
            this.pnchek.Controls.Add(this.pb4);
            this.pnchek.Controls.Add(this.pb3);
            this.pnchek.Controls.Add(this.pb2);
            this.pnchek.Controls.Add(this.pb1);
            this.pnchek.Controls.Add(this.label4);
            this.pnchek.Controls.Add(this.lborientir);
            this.pnchek.Controls.Add(this.label);
            this.pnchek.Controls.Add(this.lbcheck);
            this.pnchek.Location = new System.Drawing.Point(666, 127);
            this.pnchek.Name = "pnchek";
            this.pnchek.Size = new System.Drawing.Size(330, 407);
            this.pnchek.TabIndex = 12;
            // 
            // btclose
            // 
            this.btclose.BackgroundImage = global::pr25_26.Properties.Resources.cross_icon;
            this.btclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btclose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btclose.Location = new System.Drawing.Point(294, 9);
            this.btclose.Name = "btclose";
            this.btclose.Size = new System.Drawing.Size(30, 28);
            this.btclose.TabIndex = 21;
            this.btclose.UseVisualStyleBackColor = true;
            this.btclose.Click += new System.EventHandler(this.btclose_Click);
            // 
            // lb5
            // 
            this.lb5.BackColor = System.Drawing.Color.White;
            this.lb5.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb5.Location = new System.Drawing.Point(63, 339);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(261, 31);
            this.lb5.TabIndex = 20;
            this.lb5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lb4
            // 
            this.lb4.BackColor = System.Drawing.Color.White;
            this.lb4.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb4.Location = new System.Drawing.Point(63, 299);
            this.lb4.Name = "lb4";
            this.lb4.Size = new System.Drawing.Size(261, 31);
            this.lb4.TabIndex = 19;
            this.lb4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lb3
            // 
            this.lb3.BackColor = System.Drawing.Color.White;
            this.lb3.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb3.Location = new System.Drawing.Point(63, 259);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(261, 31);
            this.lb3.TabIndex = 18;
            this.lb3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lb2
            // 
            this.lb2.BackColor = System.Drawing.Color.White;
            this.lb2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb2.Location = new System.Drawing.Point(63, 219);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(261, 31);
            this.lb2.TabIndex = 17;
            this.lb2.Text = "Энергетические батончики";
            this.lb2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lb1
            // 
            this.lb1.BackColor = System.Drawing.Color.White;
            this.lb1.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lb1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lb1.Location = new System.Drawing.Point(63, 182);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(261, 31);
            this.lb1.TabIndex = 16;
            this.lb1.Text = "Напитки";
            this.lb1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pb5
            // 
            this.pb5.Location = new System.Drawing.Point(13, 339);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(34, 34);
            this.pb5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb5.TabIndex = 15;
            this.pb5.TabStop = false;
            // 
            // pb4
            // 
            this.pb4.Location = new System.Drawing.Point(13, 299);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(34, 34);
            this.pb4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb4.TabIndex = 14;
            this.pb4.TabStop = false;
            // 
            // pb3
            // 
            this.pb3.Location = new System.Drawing.Point(13, 259);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(34, 34);
            this.pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb3.TabIndex = 13;
            this.pb3.TabStop = false;
            // 
            // pb2
            // 
            this.pb2.Image = global::pr25_26.Properties.Resources.enrgy_bars;
            this.pb2.Location = new System.Drawing.Point(13, 219);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(34, 34);
            this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb2.TabIndex = 12;
            this.pb2.TabStop = false;
            // 
            // pb1
            // 
            this.pb1.Image = global::pr25_26.Properties.Resources.drinks;
            this.pb1.Location = new System.Drawing.Point(13, 179);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(34, 34);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb1.TabIndex = 11;
            this.pb1.TabStop = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Location = new System.Drawing.Point(0, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(324, 42);
            this.label4.TabIndex = 10;
            this.label4.Text = "Особенности";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lborientir
            // 
            this.lborientir.BackColor = System.Drawing.Color.White;
            this.lborientir.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lborientir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lborientir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lborientir.Location = new System.Drawing.Point(128, 59);
            this.lborientir.Name = "lborientir";
            this.lborientir.Size = new System.Drawing.Size(183, 62);
            this.lborientir.TabIndex = 9;
            this.lborientir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label
            // 
            this.label.BackColor = System.Drawing.Color.White;
            this.label.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label.Location = new System.Drawing.Point(3, 59);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(122, 62);
            this.label.TabIndex = 8;
            this.label.Text = "Ориентир:";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbcheck
            // 
            this.lbcheck.BackColor = System.Drawing.Color.White;
            this.lbcheck.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbcheck.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbcheck.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbcheck.Location = new System.Drawing.Point(3, 9);
            this.lbcheck.Name = "lbcheck";
            this.lbcheck.Size = new System.Drawing.Size(324, 50);
            this.lbcheck.TabIndex = 7;
            this.lbcheck.Text = "Чекпоинт";
            this.lbcheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bt1
            // 
            this.bt1.BackColor = System.Drawing.Color.Yellow;
            this.bt1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt1.Location = new System.Drawing.Point(334, 136);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(39, 35);
            this.bt1.TabIndex = 13;
            this.bt1.Text = "1";
            this.bt1.UseVisualStyleBackColor = false;
            this.bt1.Click += new System.EventHandler(this.bt1_Click);
            // 
            // bt2
            // 
            this.bt2.BackColor = System.Drawing.Color.Yellow;
            this.bt2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt2.Location = new System.Drawing.Point(434, 220);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(39, 35);
            this.bt2.TabIndex = 14;
            this.bt2.Text = "2";
            this.bt2.UseVisualStyleBackColor = false;
            this.bt2.Click += new System.EventHandler(this.bt2_Click);
            // 
            // bt3
            // 
            this.bt3.BackColor = System.Drawing.Color.Yellow;
            this.bt3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt3.Location = new System.Drawing.Point(369, 311);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(39, 35);
            this.bt3.TabIndex = 15;
            this.bt3.Text = "3";
            this.bt3.UseVisualStyleBackColor = false;
            this.bt3.Click += new System.EventHandler(this.bt3_Click);
            // 
            // bt4
            // 
            this.bt4.BackColor = System.Drawing.Color.Yellow;
            this.bt4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt4.Location = new System.Drawing.Point(397, 398);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(39, 35);
            this.bt4.TabIndex = 16;
            this.bt4.Text = "4";
            this.bt4.UseVisualStyleBackColor = false;
            this.bt4.Click += new System.EventHandler(this.bt4_Click);
            // 
            // bt5
            // 
            this.bt5.BackColor = System.Drawing.Color.Yellow;
            this.bt5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt5.Location = new System.Drawing.Point(309, 489);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(39, 35);
            this.bt5.TabIndex = 17;
            this.bt5.Text = "5";
            this.bt5.UseVisualStyleBackColor = false;
            this.bt5.Click += new System.EventHandler(this.bt5_Click);
            // 
            // bt6
            // 
            this.bt6.BackColor = System.Drawing.Color.Yellow;
            this.bt6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt6.Location = new System.Drawing.Point(211, 431);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(39, 35);
            this.bt6.TabIndex = 18;
            this.bt6.Text = "6";
            this.bt6.UseVisualStyleBackColor = false;
            this.bt6.Click += new System.EventHandler(this.bt6_Click);
            // 
            // bt7
            // 
            this.bt7.BackColor = System.Drawing.Color.Yellow;
            this.bt7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt7.Location = new System.Drawing.Point(105, 415);
            this.bt7.Name = "bt7";
            this.bt7.Size = new System.Drawing.Size(39, 35);
            this.bt7.TabIndex = 19;
            this.bt7.Text = "7";
            this.bt7.UseVisualStyleBackColor = false;
            this.bt7.Click += new System.EventHandler(this.bt7_Click);
            // 
            // bt8
            // 
            this.bt8.BackColor = System.Drawing.Color.Yellow;
            this.bt8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bt8.Location = new System.Drawing.Point(93, 263);
            this.bt8.Name = "bt8";
            this.bt8.Size = new System.Drawing.Size(39, 35);
            this.bt8.TabIndex = 20;
            this.bt8.Text = "8";
            this.bt8.UseVisualStyleBackColor = false;
            this.bt8.Click += new System.EventHandler(this.bt8_Click);
            // 
            // map
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1008, 681);
            this.Controls.Add(this.bt8);
            this.Controls.Add(this.bt7);
            this.Controls.Add(this.bt6);
            this.Controls.Add(this.bt5);
            this.Controls.Add(this.bt4);
            this.Controls.Add(this.bt3);
            this.Controls.Add(this.bt2);
            this.Controls.Add(this.bt1);
            this.Controls.Add(this.pnchek);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "map";
            this.Text = "Map";
            this.Load += new System.EventHandler(this.map_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnchek.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Panel panel1;
        private Button button2;
        private Label label3;
        private Panel panel2;
        private Panel pnchek;
        private Button bt1;
        private Button bt2;
        private Button bt3;
        private Button bt4;
        private Button bt5;
        private Button bt6;
        private Button bt7;
        private Button bt8;
        private Label lborientir;
        private Label label;
        private Label lbcheck;
        private Label lb5;
        private Label lb4;
        private Label lb3;
        private Label lb2;
        private Label lb1;
        private PictureBox pb5;
        private PictureBox pb4;
        private PictureBox pb3;
        private PictureBox pb2;
        private PictureBox pb1;
        private Label label4;
        private Button btclose;
    }
}