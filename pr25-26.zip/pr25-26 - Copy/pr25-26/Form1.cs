namespace pr25_26
{
    public partial class frmain : Form
    {
        public frmain()
        {
            InitializeComponent();
        }

        private void btBMI_Click(object sender, EventArgs e)
        {
            Hide();
            frbmi bmi = new frbmi();
            bmi.ShowDialog();
            Close();


        }

        private void btBMR_Click(object sender, EventArgs e)
        {
            Hide();
            frbmr bmr = new frbmr();
            bmr.ShowDialog();
            Close();
        }

        private void btMS2016_Click(object sender, EventArgs e)
        {
            Hide();
            frinfo info = new frinfo();
            info.ShowDialog();
            Close();
        }

        private void btHLM_Click(object sender, EventArgs e)
        {
            Hide();
            frhowlong hl = new frhowlong();
            hl.ShowDialog();
            Close();
        }
    }
}