﻿namespace pr25_26
{
    partial class frbmr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btcancel = new System.Windows.Forms.Button();
            this.btcalc = new System.Windows.Forms.Button();
            this.tbves = new System.Windows.Forms.TextBox();
            this.tbrost = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btwomen = new System.Windows.Forms.Button();
            this.btmen = new System.Windows.Forms.Button();
            this.tbage = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbbmr = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbseat = new System.Windows.Forms.Label();
            this.lbmida = new System.Windows.Forms.Label();
            this.lbsmalla = new System.Windows.Forms.Label();
            this.lbhigha = new System.Windows.Forms.Label();
            this.lbmaxa = new System.Windows.Forms.Label();
            this.btinfo = new System.Windows.Forms.Button();
            this.pninfo = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btvoff = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pninfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(227, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "MARATHON SKILLS 2016";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(298, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(408, 26);
            this.label3.TabIndex = 1;
            this.label3.Text = "18 дней 8 часов и 17 минут до старта марафона!";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(-2, 622);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1012, 59);
            this.panel2.TabIndex = 7;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1012, 54);
            this.panel1.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 48);
            this.button2.TabIndex = 44;
            this.button2.Text = "Назад";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Demi", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(31, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(246, 37);
            this.label4.TabIndex = 9;
            this.label4.Text = "BMR калькулятор";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(31, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(943, 86);
            this.label2.TabIndex = 8;
            this.label2.Text = "BMR Калькулятор- это инструмент, позволяющий узнать минимальное количество энерги" +
    "и, необходимое вашему телу, чтобы остаться в живых.\r\n";
            // 
            // btcancel
            // 
            this.btcancel.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btcancel.ForeColor = System.Drawing.Color.Black;
            this.btcancel.Location = new System.Drawing.Point(158, 540);
            this.btcancel.Name = "btcancel";
            this.btcancel.Size = new System.Drawing.Size(140, 35);
            this.btcancel.TabIndex = 31;
            this.btcancel.Text = "Отмена";
            this.btcancel.UseVisualStyleBackColor = true;
            this.btcancel.Click += new System.EventHandler(this.btcancel_Click);
            // 
            // btcalc
            // 
            this.btcalc.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btcalc.ForeColor = System.Drawing.Color.Black;
            this.btcalc.Location = new System.Drawing.Point(12, 540);
            this.btcalc.Name = "btcalc";
            this.btcalc.Size = new System.Drawing.Size(140, 35);
            this.btcalc.TabIndex = 30;
            this.btcalc.Text = "Расcчитать";
            this.btcalc.UseVisualStyleBackColor = true;
            this.btcalc.Click += new System.EventHandler(this.btcalc_Click);
            // 
            // tbves
            // 
            this.tbves.Location = new System.Drawing.Point(119, 409);
            this.tbves.Name = "tbves";
            this.tbves.Size = new System.Drawing.Size(57, 23);
            this.tbves.TabIndex = 29;
            // 
            // tbrost
            // 
            this.tbrost.Location = new System.Drawing.Point(119, 366);
            this.tbrost.Name = "tbrost";
            this.tbrost.Size = new System.Drawing.Size(57, 23);
            this.tbrost.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.Gray;
            this.label9.Location = new System.Drawing.Point(182, 409);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 25);
            this.label9.TabIndex = 27;
            this.label9.Text = "кг";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(182, 366);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 25);
            this.label10.TabIndex = 26;
            this.label10.Text = "см";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.Gray;
            this.label8.Location = new System.Drawing.Point(75, 409);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 23);
            this.label8.TabIndex = 25;
            this.label8.Text = "Вес:";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.Gray;
            this.label7.Location = new System.Drawing.Point(65, 366);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 23);
            this.label7.TabIndex = 24;
            this.label7.Text = "Рост:";
            // 
            // btwomen
            // 
            this.btwomen.BackgroundImage = global::pr25_26.Properties.Resources.female;
            this.btwomen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btwomen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btwomen.Location = new System.Drawing.Point(167, 192);
            this.btwomen.Name = "btwomen";
            this.btwomen.Size = new System.Drawing.Size(111, 100);
            this.btwomen.TabIndex = 23;
            this.btwomen.UseVisualStyleBackColor = true;
            this.btwomen.Click += new System.EventHandler(this.btwomen_Click);
            // 
            // btmen
            // 
            this.btmen.BackgroundImage = global::pr25_26.Properties.Resources.male;
            this.btmen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btmen.FlatAppearance.BorderSize = 3;
            this.btmen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btmen.Location = new System.Drawing.Point(32, 192);
            this.btmen.Name = "btmen";
            this.btmen.Size = new System.Drawing.Size(111, 100);
            this.btmen.TabIndex = 22;
            this.btmen.UseVisualStyleBackColor = true;
            this.btmen.Click += new System.EventHandler(this.btmen_Click);
            // 
            // tbage
            // 
            this.tbage.Location = new System.Drawing.Point(119, 450);
            this.tbage.Name = "tbage";
            this.tbage.Size = new System.Drawing.Size(57, 23);
            this.tbage.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(182, 450);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 25);
            this.label5.TabIndex = 33;
            this.label5.Text = "лет";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(32, 450);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 23);
            this.label6.TabIndex = 32;
            this.label6.Text = "Возраст:";
            // 
            // lbbmr
            // 
            this.lbbmr.AutoSize = true;
            this.lbbmr.Font = new System.Drawing.Font("Franklin Gothic Demi", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbbmr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbbmr.Location = new System.Drawing.Point(448, 229);
            this.lbbmr.Name = "lbbmr";
            this.lbbmr.Size = new System.Drawing.Size(160, 37);
            this.lbbmr.TabIndex = 35;
            this.lbbmr.Text = "Ваш BMR: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(448, 289);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(315, 25);
            this.label12.TabIndex = 36;
            this.label12.Text = "Ежедневно тратиться каллорий:";
            // 
            // lbseat
            // 
            this.lbseat.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbseat.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbseat.Location = new System.Drawing.Point(413, 326);
            this.lbseat.Name = "lbseat";
            this.lbseat.Size = new System.Drawing.Size(350, 25);
            this.lbseat.TabIndex = 37;
            this.lbseat.Text = "Сидячий: 0";
            this.lbseat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbmida
            // 
            this.lbmida.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbmida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbmida.Location = new System.Drawing.Point(387, 401);
            this.lbmida.Name = "lbmida";
            this.lbmida.Size = new System.Drawing.Size(376, 25);
            this.lbmida.TabIndex = 39;
            this.lbmida.Text = "Средняя активность: 0";
            this.lbmida.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbsmalla
            // 
            this.lbsmalla.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbsmalla.ForeColor = System.Drawing.Color.Green;
            this.lbsmalla.Location = new System.Drawing.Point(387, 364);
            this.lbsmalla.Name = "lbsmalla";
            this.lbsmalla.Size = new System.Drawing.Size(376, 25);
            this.lbsmalla.TabIndex = 38;
            this.lbsmalla.Text = "Маленькая активность: 0";
            this.lbsmalla.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbhigha
            // 
            this.lbhigha.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbhigha.ForeColor = System.Drawing.Color.Red;
            this.lbhigha.Location = new System.Drawing.Point(387, 438);
            this.lbhigha.Name = "lbhigha";
            this.lbhigha.Size = new System.Drawing.Size(376, 25);
            this.lbhigha.TabIndex = 40;
            this.lbhigha.Text = "Сильная активность: 0";
            this.lbhigha.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbmaxa
            // 
            this.lbmaxa.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbmaxa.ForeColor = System.Drawing.Color.Maroon;
            this.lbmaxa.Location = new System.Drawing.Point(387, 475);
            this.lbmaxa.Name = "lbmaxa";
            this.lbmaxa.Size = new System.Drawing.Size(376, 25);
            this.lbmaxa.TabIndex = 41;
            this.lbmaxa.Text = "Макисмальная активность: 0";
            this.lbmaxa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btinfo
            // 
            this.btinfo.BackgroundImage = global::pr25_26.Properties.Resources.information;
            this.btinfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btinfo.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btinfo.ForeColor = System.Drawing.Color.Black;
            this.btinfo.Location = new System.Drawing.Point(769, 286);
            this.btinfo.Name = "btinfo";
            this.btinfo.Size = new System.Drawing.Size(35, 35);
            this.btinfo.TabIndex = 42;
            this.btinfo.UseVisualStyleBackColor = true;
            this.btinfo.Click += new System.EventHandler(this.btinfo_Click);
            // 
            // pninfo
            // 
            this.pninfo.Controls.Add(this.label21);
            this.pninfo.Controls.Add(this.label28);
            this.pninfo.Controls.Add(this.label27);
            this.pninfo.Controls.Add(this.label26);
            this.pninfo.Controls.Add(this.label25);
            this.pninfo.Controls.Add(this.label24);
            this.pninfo.Controls.Add(this.label23);
            this.pninfo.Controls.Add(this.label22);
            this.pninfo.Controls.Add(this.label20);
            this.pninfo.Controls.Add(this.label19);
            this.pninfo.Controls.Add(this.btvoff);
            this.pninfo.Controls.Add(this.label18);
            this.pninfo.Location = new System.Drawing.Point(376, 210);
            this.pninfo.Name = "pninfo";
            this.pninfo.Size = new System.Drawing.Size(561, 320);
            this.pninfo.TabIndex = 43;
            this.pninfo.Visible = false;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(6, 264);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(125, 23);
            this.label21.TabIndex = 36;
            this.label21.Text = "Максимальная:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label28.ForeColor = System.Drawing.Color.Gray;
            this.label28.Location = new System.Drawing.Point(137, 267);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(421, 45);
            this.label28.TabIndex = 43;
            this.label28.Text = "Профессиональный спорт\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nНЕ ТРОГАЙ, ЗАПРИВАЧЕНО";
            // 
            // label27
            // 
            this.label27.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label27.ForeColor = System.Drawing.Color.Gray;
            this.label27.Location = new System.Drawing.Point(137, 216);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(421, 45);
            this.label27.TabIndex = 42;
            this.label27.Text = "Активный образ жизни, который учитывает очень тяжелую физическую работу или силов" +
    "ую тренеровку";
            // 
            // label26
            // 
            this.label26.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label26.ForeColor = System.Drawing.Color.Gray;
            this.label26.Location = new System.Drawing.Point(137, 168);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(421, 45);
            this.label26.TabIndex = 41;
            this.label26.Text = "Для умеренной физической активности";
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label25.ForeColor = System.Drawing.Color.Gray;
            this.label25.Location = new System.Drawing.Point(137, 116);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(421, 45);
            this.label25.TabIndex = 40;
            this.label25.Text = "При низкой физичесткой активности, например, сидячий образ жизни в сочении с крат" +
    "ковременными походами\r\n";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label24.ForeColor = System.Drawing.Color.Gray;
            this.label24.Location = new System.Drawing.Point(137, 59);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(421, 45);
            this.label24.TabIndex = 39;
            this.label24.Text = "В случае неподвижности, например, постельный режим из-за болезни\r\n";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(34, 116);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(96, 23);
            this.label23.TabIndex = 38;
            this.label23.Text = "Маленькая:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(55, 216);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(76, 23);
            this.label22.TabIndex = 37;
            this.label22.Text = "Сильная:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(55, 168);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 23);
            this.label20.TabIndex = 35;
            this.label20.Text = "Средняя:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(52, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 23);
            this.label19.TabIndex = 34;
            this.label19.Text = "Сидячий:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btvoff
            // 
            this.btvoff.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btvoff.ForeColor = System.Drawing.Color.Black;
            this.btvoff.Location = new System.Drawing.Point(487, 3);
            this.btvoff.Name = "btvoff";
            this.btvoff.Size = new System.Drawing.Size(71, 35);
            this.btvoff.TabIndex = 32;
            this.btvoff.Text = "Скрыть";
            this.btvoff.UseVisualStyleBackColor = true;
            this.btvoff.Click += new System.EventHandler(this.btvoff_Click);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.ForeColor = System.Drawing.Color.Gray;
            this.label18.Location = new System.Drawing.Point(3, 7);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(555, 23);
            this.label18.TabIndex = 33;
            this.label18.Text = "Уровни активности";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frbmr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1008, 681);
            this.Controls.Add(this.pninfo);
            this.Controls.Add(this.btinfo);
            this.Controls.Add(this.lbmaxa);
            this.Controls.Add(this.lbhigha);
            this.Controls.Add(this.lbmida);
            this.Controls.Add(this.lbsmalla);
            this.Controls.Add(this.lbseat);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbbmr);
            this.Controls.Add(this.tbage);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btcancel);
            this.Controls.Add(this.btcalc);
            this.Controls.Add(this.tbves);
            this.Controls.Add(this.tbrost);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btwomen);
            this.Controls.Add(this.btmen);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frbmr";
            this.Text = "BMR";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pninfo.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label3;
        private Panel panel2;
        private Panel panel1;
        private Label label4;
        private Label label2;
        private Button btcancel;
        private Button btcalc;
        private TextBox tbves;
        private TextBox tbrost;
        private Label label9;
        private Label label10;
        private Label label8;
        private Label label7;
        private Button btwomen;
        private Button btmen;
        private TextBox tbage;
        private Label label5;
        private Label label6;
        private Label lbbmr;
        private Label label12;
        private Label lbseat;
        private Label lbmida;
        private Label lbsmalla;
        private Label lbhigha;
        private Label lbmaxa;
        private Button btinfo;
        private Panel pninfo;
        private Button btvoff;
        private Label label21;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label20;
        private Label label19;
        private Label label18;
        private Button button2;
    }
}