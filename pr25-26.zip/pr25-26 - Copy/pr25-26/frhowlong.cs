﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr25_26
{
    public partial class frhowlong : Form
    {
        public Image f1_car = Properties.Resources.f1_car;
        public Image worm = Properties.Resources.worm;
        public Image sloth = Properties.Resources.sloth;
        public Image capibara = Properties.Resources.capybara;
        public Image jaguar = Properties.Resources.jaguar;
        public Image a380 = Properties.Resources.airbus_a380;
        public Image tapki = Properties.Resources.pair_of_havaianas;
        public Image pole = Properties.Resources.football_field;
        public Image men = Properties.Resources.ronaldinho;
        public Image bus = Properties.Resources.bus;
        public frhowlong()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            frmain main=new frmain();
            main.ShowDialog();
            Close();
        }
        public void ResultTime(string name, double speed)
        {
            double hour = 42 / speed;
            double celHour = Math.Truncate(hour);
            double ostFromHour = hour - celHour;
            double minuts = ostFromHour * 60;
            double celMinuts = Math.Truncate(minuts);
            double ostFromMinuts = minuts - celMinuts;
            double celseconds = Math.Round(ostFromMinuts * 60, 0);
            lbinfo.Text = $"Максимальная скорость {name}: {speed}км/ч.\nЭто займет {celHour} часов, {celMinuts} минут, {celseconds} секунд, чтобы завершить 42км марафон.";
        }
        public void ResultRast(string name, double dlina)
        {
            double sectors = 4200 / dlina;
            double kolv = Math.Truncate(sectors);
            double ostatok = sectors - kolv;
            if (ostatok > 0) kolv++;
            lbinfo.Text = $"Длина {name}: {dlina}. Их будет находиться: {kolv} на расстоянии 42км.";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pbmain.Image = f1_car;
            lbname.Text = "Автомобиль Формулы-1";
            ResultTime(lbname.Text, 345);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pbmain.Image = worm;
            lbname.Text = "Червяк";
            ResultTime(lbname.Text, 0.03);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pbmain.Image = sloth;
            lbname.Text = "Ленивец";
            ResultTime(lbname.Text, 0.12);
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pbmain.Image = capibara;
            lbname.Text = "Капибара";
            ResultTime(lbname.Text, 35);
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            pbmain.Image = jaguar;
            lbname.Text = "Ягуар";
            ResultTime(lbname.Text, 80);
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            pbmain.Image = a380;
            lbname.Text = "Airbus A380";
            ResultRast(lbname.Text, 73);
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            pbmain.Image = tapki;
            lbname.Text = "Havaianas";
            ResultRast(lbname.Text, 0.245);
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            pbmain.Image = pole;
            lbname.Text = "Футбольное поле";
            ResultRast(lbname.Text, 105);
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            pbmain.Image = men;
            lbname.Text = "Роналдиньо";
            ResultRast(lbname.Text, 1.81);
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            pbmain.Image = bus;
            lbname.Text = "Автобус";
            ResultRast(lbname.Text, 10);
        }
    }
}
