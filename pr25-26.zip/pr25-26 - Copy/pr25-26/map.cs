﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr25_26
{
    public partial class map : Form
    {
        private Image drinks = Properties.Resources.drinks;
        private Image enrgy_bars = Properties.Resources.enrgy_bars;
        private Image toilets = Properties.Resources.toilets;
        private Image inform = Properties.Resources.information;
        private Image medical = Properties.Resources.medical;
        public map()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            frinfo info = new frinfo();
            info.ShowDialog();
            Close();
        }
        public void CirclButton(Control control)
        {
            GraphicsPath gp = new GraphicsPath();
            Graphics g;
            g = CreateGraphics();
            Rectangle rectangle = control.ClientRectangle;
            rectangle.Inflate(-3, -3);
            gp.AddEllipse(rectangle);
            control.Region = new Region(gp);
            g.DrawEllipse(new Pen(Color.FromArgb(255, 255, 128), 1),
            control.Left + 1,
            control.Top + 1, control.Width - 3, control.Height - 3);
            g.Dispose();
        }
        private void map_Load(object sender, EventArgs e)
        {
            CirclButton(bt1);
            CirclButton(bt2);
            CirclButton(bt3);
            CirclButton(bt4);
            CirclButton(bt5);
            CirclButton(bt6);
            CirclButton(bt7);
            CirclButton(bt8);
        }
        private void ClearPanel()
        {

            pb3.Image = null;
            pb4.Image = null;
            pb5.Image = null;


            lb3.Text = "";
            lb4.Text = "";
            lb5.Text = "";

        }

        private void bt1_Click(object sender, EventArgs e)
        {
            ClearPanel();
            pnchek.Visible = true;
            lbcheck.Text = "Чекпоинт 1";
            lborientir.Text = "Avenida Rudge";
        }

        private void bt2_Click(object sender, EventArgs e)
        {
            ClearPanel();
            lbcheck.Text = "Чекпоинт 2";
            pnchek.Visible = true;
            lborientir.Text = "Theatro Municipal";
            pb3.Image = toilets;
            pb4.Image = inform;
            pb5.Image = medical;
            lb3.Text = "Туалет";
            lb4.Text = "Инф.Пункт";
            lb5.Text = "Медпункт";
        }

        private void bt3_Click(object sender, EventArgs e)
        {
            ClearPanel();
            lbcheck.Text = "Чекпоинт 3";
            pnchek.Visible = true;
            lborientir.Text = "Parque do Ibirapuera";
            pb3.Image = toilets;
            lb3.Text = "Туалет";
        }

        private void bt4_Click(object sender, EventArgs e)
        {
            ClearPanel();
            lbcheck.Text = "Чекпоинт 4";
            pnchek.Visible = true;
            lborientir.Text = "Jardim Luzitania";
            pb3.Image = toilets;
            pb4.Image = medical;
            lb3.Text = "Туалет";
            lb4.Text = "Медпункт";
        }

        private void bt5_Click(object sender, EventArgs e)
        {
            ClearPanel();
            lbcheck.Text = "Чекпоинт 5";
            pnchek.Visible = true;
            lborientir.Text = "Iguatemi";
            pb3.Image = toilets;
            pb4.Image = inform;
            lb3.Text = "Туалет";
            lb4.Text = "Инф.Пункт";
        }

        private void bt6_Click(object sender, EventArgs e)
        {
            ClearPanel();
            lbcheck.Text = "Чекпоинт 6";
            pnchek.Visible = true;
            lborientir.Text = "Rua Lisboa";
            pb3.Image = toilets;
            lb3.Text = "Туалет";
        }

        private void bt7_Click(object sender, EventArgs e)
        {
            ClearPanel();
            lbcheck.Text = "Чекпоинт 7";
            pnchek.Visible = true;
            lborientir.Text = "Cemitério da Consolação";
            pb3.Image = toilets;
            pb4.Image = inform;
            pb5.Image = medical;
            lb3.Text = "Туалет";
            lb4.Text = "Инф.Пункт";
            lb5.Text = "Медпункт";
        }

        private void bt8_Click(object sender, EventArgs e)
        {
            ClearPanel();
            lbcheck.Text = "Чекпоинт 8";
            pnchek.Visible = true;
            lborientir.Text = "Cemitério da Consolação";
            pb3.Image = toilets;
            pb4.Image = inform;
            pb5.Image = medical;
            lb3.Text = "Туалет";
            lb4.Text = "Инф.Пункт";
            lb5.Text = "Медпункт";
        }

        private void btclose_Click(object sender, EventArgs e)
        {
            ClearPanel();
            pnchek.Visible = false;
        }
    }
}
